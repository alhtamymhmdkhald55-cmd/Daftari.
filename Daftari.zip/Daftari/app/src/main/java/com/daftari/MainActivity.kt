package com.daftari

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class Db(c: Context) : SQLiteOpenHelper(c, "daftari.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT)")
        d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,cid INTEGER,amount REAL,note TEXT,type TEXT,method TEXT,ts INTEGER)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}
}

class MainActivity : Activity() {
    lateinit var db: SQLiteDatabase
    var back: (() -> Unit)? = null
    val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val GREEN = 0xFF2E7D32.toInt(); val RED = 0xFFC62828.toInt(); val GRAY = 0xFF455A64.toInt(); val BLUE = 0xFF1565C0.toInt()
    val methods = listOf("نقد - مناولة يد", "جيب", "ون كاش", "فلوسك", "كريمي جوي / جوال", "حوالة الكريمي", "حوالة النجم", "بنك")

    override fun onCreate(b: Bundle?) { super.onCreate(b); db = Db(this).writableDatabase; home() }
    @Suppress("DEPRECATION")
    override fun onBackPressed() { val f = back; if (f != null) f() else super.onBackPressed() }

    // ---------- helpers ----------
    fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()
    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    fun root() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
    fun show(l: View) { setContentView(ScrollView(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL; addView(l) }) }
    fun text(s: String, size: Float = 20f, color: Int = Color.BLACK) = TextView(this).apply { text = s; textSize = size; setTextColor(color); setPadding(0, dp(6), 0, dp(6)) }
    fun button(s: String, color: Int = GRAY, f: () -> Unit) = Button(this).apply {
        text = s; textSize = 20f; setTextColor(Color.WHITE); setBackgroundColor(color)
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(60)).apply { topMargin = dp(8) }
    }
    fun edit(h: String, t: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply { hint = h; textSize = 22f; inputType = t }
    fun money(d: Double) = if (d == Math.floor(d)) d.toLong().toString() else String.format(Locale.US, "%.2f", d)

    fun balance(cid: Long): Double {
        val c = db.rawQuery("SELECT COALESCE(SUM(CASE WHEN type='debt' THEN amount ELSE -amount END),0) FROM tx WHERE cid=?", arrayOf("$cid"))
        c.moveToFirst(); val v = c.getDouble(0); c.close(); return v
    }
    fun overdue(cid: Long, bal: Double): Boolean {
        if (bal <= 0) return false
        val c = db.rawQuery("SELECT COALESCE((SELECT MAX(ts) FROM tx WHERE cid=? AND type='pay'),(SELECT MIN(ts) FROM tx WHERE cid=?))", arrayOf("$cid", "$cid"))
        c.moveToFirst(); val ts = c.getLong(0); c.close()
        return ts > 0 && System.currentTimeMillis() - ts > 15 * 86400000L
    }
    fun wa(phone: String, msg: String) {
        var p = phone.filter { it.isDigit() }
        if (p.startsWith("0")) p = p.drop(1)
        if (p.length == 9) p = "967$p"
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$p?text=" + Uri.encode(msg)))) }
        catch (e: Exception) { toast("تعذر فتح واتساب") }
    }

    // ---------- calculator ----------
    fun evalExpr(s: String): Double? {
        val t = Regex("\\d+\\.?\\d*|[+\\-×÷]").findAll(s).map { it.value }.toList()
        if (t.isEmpty()) return null
        var cur = t[0].toDoubleOrNull() ?: return null
        val terms = mutableListOf<Double>(); val adds = mutableListOf<String>()
        var i = 1
        while (i < t.size) {
            val op = t[i]; val n = t.getOrNull(i + 1)?.toDoubleOrNull() ?: break
            when (op) {
                "×" -> { cur *= n }
                "÷" -> { if (n == 0.0) return null; cur /= n }
                else -> { terms.add(cur); adds.add(op); cur = n }
            }
            i += 2
        }
        terms.add(cur)
        var res = terms[0]
        for (k in adds.indices) res = if (adds[k] == "+") res + terms[k + 1] else res - terms[k + 1]
        return res
    }
    fun calc(onApply: ((String) -> Unit)?) {
        var expr = ""
        val d = AlertDialog.Builder(this).create()
        val l = root()
        val e = text("", 22f, Color.GRAY); val r = text("0", 38f)
        l.addView(e); l.addView(r)
        fun upd() { e.text = expr; r.text = evalExpr(expr)?.let { money(it) } ?: "0" }
        val g = GridLayout(this); g.columnCount = 4
        listOf("7", "8", "9", "÷", "4", "5", "6", "×", "1", "2", "3", "-", "0", ".", "+", "⌫").forEach { k ->
            g.addView(Button(this).apply {
                text = k; textSize = 24f
                setOnClickListener { if (k == "⌫") expr = expr.dropLast(1) else expr += k; upd() }
            }, GridLayout.LayoutParams().apply { width = dp(76); height = dp(70) })
        }
        l.addView(g)
        l.addView(button("مسح") { expr = ""; upd() })
        if (onApply != null) l.addView(button("تطبيق المبلغ", GREEN) {
            val v = evalExpr(expr)
            if (v != null) { onApply(money(v)); d.dismiss() }
        })
        d.setView(l); d.show()
    }

    // ---------- screens ----------
    fun home() {
        back = null
        val l = root()
        l.addView(text("📒 دفتري", 30f)); l.addView(text("دفترك وحاسبتك في جيبك", 16f, Color.GRAY))
        l.addView(button("➕ إضافة زبون", GREEN) { addCustomer() })
        l.addView(button("🧮 حاسبة", BLUE) { calc(null) })
        l.addView(button("📊 تقرير اليوم", 0xFF6A1B9A.toInt()) { report() })
        val c = db.rawQuery("SELECT id,name FROM customers ORDER BY name", null)
        while (c.moveToNext()) {
            val id = c.getLong(0); val bal = balance(id)
            l.addView(button("${c.getString(1)} — ${money(bal)}", if (overdue(id, bal)) RED else GRAY) { customer(id) })
        }
        c.close(); show(l)
    }

    fun addCustomer() {
        back = { home() }
        val l = root()
        l.addView(text("إضافة زبون", 26f))
        val n = edit("اسم الحساب"); val p = edit("رقم الواتساب", InputType.TYPE_CLASS_PHONE)
        l.addView(n); l.addView(p)
        l.addView(button("حفظ", GREEN) {
            if (n.text.isBlank()) { toast("اكتب الاسم"); return@button }
            db.insert("customers", null, ContentValues().apply { put("name", n.text.toString().trim()); put("phone", p.text.toString().trim()) })
            home()
        })
        show(l)
    }

    fun customer(id: Long) {
        back = { home() }
        val c = db.rawQuery("SELECT name,phone FROM customers WHERE id=?", arrayOf("$id"))
        c.moveToFirst(); val name = c.getString(0); val phone = c.getString(1); c.close()
        val bal = balance(id)
        val l = root()
        l.addView(text(name, 28f)); l.addView(text("الباقي عليه: ${money(bal)}", 24f, if (bal > 0) RED else GREEN))
        l.addView(button("➕ إضافة دين", RED) { txScreen(id, "debt") })
        l.addView(button("✅ تسديد", GREEN) { txScreen(id, "pay") })
        l.addView(button("📄 كشف حساب", BLUE) { statement(id, 3) })
        l.addView(button("🔔 ذكره بالواتساب") { wa(phone, "السلام عليكم $name، نذكرك بأن الباقي عليك ${money(bal)} ريال. شكرا لك.") })
        show(l)
    }

    fun txScreen(id: Long, type: String) {
        back = { customer(id) }
        val pay = type == "pay"
        val l = root()
        l.addView(text(if (pay) "تسديد" else "تسجيل دين", 26f))
        val amt = edit("المبلغ", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val row = LinearLayout(this)
        row.addView(amt, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "🧮"; textSize = 22f; setOnClickListener { calc { v -> amt.setText(v) } } })
        l.addView(row)
        val note = edit(if (pay) "البيان" else "المناولة / القيمة"); l.addView(note)
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, methods) }
        if (pay) l.addView(sp) else {
            val hs = HorizontalScrollView(this); val r = LinearLayout(this)
            listOf("رز", "سكر", "زيت", "دقيق", "بيض", "مناولة", "سداد مناولة").forEach { w ->
                r.addView(Button(this).apply { text = w; setOnClickListener { note.setText((note.text.toString() + " " + w).trim()) } })
            }
            hs.addView(r); l.addView(hs)
        }
        l.addView(button(if (pay) "تأكيد السداد" else "حفظ كـ دين", if (pay) GREEN else RED) {
            val a = amt.text.toString().toDoubleOrNull()
            if (a == null || a <= 0) { toast("اكتب المبلغ"); return@button }
            db.insert("tx", null, ContentValues().apply {
                put("cid", id); put("amount", a); put("note", note.text.toString()); put("type", type)
                put("method", if (pay) sp.selectedItem.toString() else ""); put("ts", System.currentTimeMillis())
            })
            customer(id)
        })
        show(l)
    }

    fun statement(id: Long, f: Int) {
        back = { customer(id) }
        val c0 = db.rawQuery("SELECT name,phone FROM customers WHERE id=?", arrayOf("$id"))
        c0.moveToFirst(); val name = c0.getString(0); val phone = c0.getString(1); c0.close()
        val now = System.currentTimeMillis()
        val day = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val from = when (f) { 0 -> day; 1 -> now - 7 * 86400000L; 2 -> now - 30 * 86400000L; else -> 0L }
        val l = root(); val sb = StringBuilder("كشف حساب: $name\n")
        var debt = 0.0; var paid = 0.0
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val c = db.rawQuery("SELECT ts,amount,note,type,method FROM tx WHERE cid=? AND ts>=? ORDER BY ts", arrayOf("$id", "$from"))
        while (c.moveToNext()) {
            val isDebt = c.getString(3) == "debt"; val a = c.getDouble(1)
            if (isDebt) debt += a else paid += a
            val line = "${fmt.format(Date(c.getLong(0)))} | ${money(a)} | ${c.getString(2)} | ${if (isDebt) "دين" else "تسديد"} ${c.getString(4)}"
            rows.addView(text(line, 16f, if (isDebt) RED else GREEN)); sb.append(line).append('\n')
        }
        c.close()
        sb.append("إجمالي الدين: ${money(debt)} | المسدد: ${money(paid)} | الباقي: ${money(debt - paid)}")
        l.addView(text("كشف حساب: $name", 26f))
        l.addView(text("الدين ${money(debt)} | المسدد ${money(paid)} | الباقي ${money(debt - paid)}", 18f))
        val fr = LinearLayout(this)
        listOf("اليوم", "الأسبوع", "الشهر", "كامل").forEachIndexed { i, s -> fr.addView(Button(this).apply { text = s; setOnClickListener { statement(id, i) } }) }
        l.addView(fr); l.addView(rows)
        l.addView(button("📤 أرسل الكشف واتساب", GREEN) { wa(phone, sb.toString()) })
        show(l)
    }

    fun report() {
        val day = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val sb = StringBuilder()
        val c = db.rawQuery("SELECT method,SUM(amount) FROM tx WHERE type='pay' AND ts>=? GROUP BY method", arrayOf("$day"))
        while (c.moveToNext()) sb.append("${c.getString(0)}: ${money(c.getDouble(1))}\n")
        c.close()
        AlertDialog.Builder(this).setTitle("تقرير اليوم").setMessage(if (sb.isEmpty()) "لا توجد مدفوعات اليوم" else sb.toString()).setPositiveButton("تم", null).show()
    }
}
